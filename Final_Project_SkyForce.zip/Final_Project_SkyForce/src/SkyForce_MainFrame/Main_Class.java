package SkyForce_MainFrame;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JOptionPane;

public class Main_Class {
	private static int point;
	 static StringBuilder stringbuilder;
	public int getPrivousPoint() {
		return point;
	}
		public static void main(String[] x) {
	    	//game= new Game_Maintaining("Sky Force ",500,600);
	    	//game.start();
			Home home=new Home();
    
   }
}